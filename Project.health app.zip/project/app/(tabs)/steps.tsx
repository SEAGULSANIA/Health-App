import { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, Image, TouchableOpacity, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Trophy, Target, Flame, Clock, ArrowUpRight } from 'lucide-react-native';
import { usePedometer } from '@/hooks/usePedometer';
import Animated, { useAnimatedStyle, withSpring } from 'react-native-reanimated';

const DAILY_GOAL = 10000;

export default function StepsScreen() {
  const { steps, error } = usePedometer();
  const [weeklySteps, setWeeklySteps] = useState([
    { day: 'Mon', steps: 8432 },
    { day: 'Tue', steps: 10251 },
    { day: 'Wed', steps: 7654 },
    { day: 'Thu', steps: 9123 },
    { day: 'Fri', steps: 11234 },
    { day: 'Sat', steps: 6543 },
    { day: 'Sun', steps: steps },
  ]);

  const percentage = Math.min((steps / DAILY_GOAL) * 100, 100);
  
  const progressStyle = useAnimatedStyle(() => ({
    width: withSpring(`${percentage}%`, { damping: 15 }),
  }));

  // Calculate calories burned (rough estimate)
  const caloriesBurned = Math.round(steps * 0.04);
  
  // Calculate distance (rough estimate in km)
  const distance = (steps * 0.762) / 1000; // Average step length of 76.2cm

  // Calculate active minutes (rough estimate)
  const activeMinutes = Math.round(steps / 100);

  useEffect(() => {
    setWeeklySteps(prev => {
      const newSteps = [...prev];
      newSteps[6].steps = steps;
      return newSteps;
    });
  }, [steps]);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <Text style={styles.title}>Step Counter</Text>

        <View style={styles.heroCard}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800' }}
            style={styles.heroImage}
          />
          <View style={styles.heroContent}>
            <View style={styles.stepsContainer}>
              <Text style={styles.stepsCount}>{steps.toLocaleString()}</Text>
              <Text style={styles.stepsLabel}>steps today</Text>
            </View>
            <View style={styles.progressBarContainer}>
              <Animated.View style={[styles.progressBar, progressStyle]} />
            </View>
            <Text style={styles.goalText}>Daily Goal: {DAILY_GOAL.toLocaleString()} steps</Text>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Flame size={24} color="#FF3B30" />
            <Text style={styles.statValue}>{caloriesBurned}</Text>
            <Text style={styles.statLabel}>Calories</Text>
          </View>
          <View style={styles.statCard}>
            <Target size={24} color="#34C759" />
            <Text style={styles.statValue}>{distance.toFixed(2)}km</Text>
            <Text style={styles.statLabel}>Distance</Text>
          </View>
          <View style={styles.statCard}>
            <Clock size={24} color="#007AFF" />
            <Text style={styles.statValue}>{activeMinutes}</Text>
            <Text style={styles.statLabel}>Active Min</Text>
          </View>
        </View>

        <View style={styles.weeklyContainer}>
          <View style={styles.weeklyHeader}>
            <Text style={styles.sectionTitle}>Weekly Progress</Text>
            <TouchableOpacity style={styles.viewAllButton}>
              <Text style={styles.viewAllText}>View All</Text>
              <ArrowUpRight size={16} color="#007AFF" />
            </TouchableOpacity>
          </View>
          <View style={styles.weeklyChart}>
            {weeklySteps.map((day, index) => {
              const barHeight = (day.steps / DAILY_GOAL) * 150;
              return (
                <View key={day.day} style={styles.chartBar}>
                  <View style={styles.barContainer}>
                    <View
                      style={[
                        styles.bar,
                        {
                          height: barHeight,
                          backgroundColor: day.steps >= DAILY_GOAL ? '#34C759' : '#007AFF',
                        },
                      ]}
                    />
                  </View>
                  <Text style={styles.barLabel}>{day.day}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <View style={styles.achievementsCard}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800' }}
            style={styles.achievementsBg}
          />
          <View style={styles.achievementsContent}>
            <View style={styles.achievementHeader}>
              <Trophy size={24} color="#FFD700" />
              <Text style={styles.achievementTitle}>Today's Achievements</Text>
            </View>
            {steps >= 5000 && (
              <View style={styles.achievement}>
                <View style={[styles.achievementIcon, { backgroundColor: '#E3F2FF' }]}>
                  <Trophy size={20} color="#007AFF" />
                </View>
                <View style={styles.achievementInfo}>
                  <Text style={styles.achievementName}>5K Steps</Text>
                  <Text style={styles.achievementDesc}>Completed 5,000 steps today</Text>
                </View>
              </View>
            )}
            {steps >= 7500 && (
              <View style={styles.achievement}>
                <View style={[styles.achievementIcon, { backgroundColor: '#E8FAE9' }]}>
                  <Trophy size={20} color="#34C759" />
                </View>
                <View style={styles.achievementInfo}>
                  <Text style={styles.achievementName}>7.5K Champion</Text>
                  <Text style={styles.achievementDesc}>Reached 7,500 steps milestone</Text>
                </View>
              </View>
            )}
            {steps >= 10000 && (
              <View style={styles.achievement}>
                <View style={[styles.achievementIcon, { backgroundColor: '#FFE5E5' }]}>
                  <Trophy size={20} color="#FF3B30" />
                </View>
                <View style={styles.achievementInfo}>
                  <Text style={styles.achievementName}>10K Master</Text>
                  <Text style={styles.achievementDesc}>Achieved daily goal of 10,000 steps</Text>
                </View>
              </View>
            )}
          </View>
        </View>

        {error && (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>
              {Platform.OS === 'web'
                ? 'Step counting is simulated on web. Try on a mobile device for actual step tracking.'
                : error}
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 32,
    color: '#000',
    marginBottom: 24,
  },
  heroCard: {
    height: 240,
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  heroImage: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    opacity: 0.1,
  },
  heroContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  stepsContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  stepsCount: {
    fontFamily: 'Inter_700Bold',
    fontSize: 48,
    color: '#007AFF',
  },
  stepsLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 16,
    color: '#666',
    marginTop: 4,
  },
  progressBarContainer: {
    width: '100%',
    height: 8,
    backgroundColor: '#F1F1F1',
    borderRadius: 4,
    marginBottom: 12,
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#007AFF',
    borderRadius: 4,
  },
  goalText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginHorizontal: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  statValue: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 20,
    color: '#000',
    marginTop: 8,
  },
  statLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  weeklyContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  weeklyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  sectionTitle: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 20,
    color: '#000',
  },
  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  viewAllText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: '#007AFF',
    marginRight: 4,
  },
  weeklyChart: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 180,
  },
  chartBar: {
    alignItems: 'center',
    flex: 1,
  },
  barContainer: {
    height: 150,
    justifyContent: 'flex-end',
  },
  bar: {
    width: 8,
    borderRadius: 4,
  },
  barLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: '#666',
    marginTop: 8,
  },
  achievementsCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  achievementsBg: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    opacity: 0.05,
  },
  achievementsContent: {
    padding: 20,
  },
  achievementHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  achievementTitle: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 18,
    color: '#000',
    marginLeft: 8,
  },
  achievement: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F1F1',
  },
  achievementIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  achievementInfo: {
    flex: 1,
  },
  achievementName: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 16,
    color: '#000',
  },
  achievementDesc: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  errorContainer: {
    backgroundColor: '#FFE5E5',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
  },
  errorText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#FF3B30',
    textAlign: 'center',
  },
});