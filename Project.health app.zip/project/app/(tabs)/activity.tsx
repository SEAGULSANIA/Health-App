import { View, Text, ScrollView, StyleSheet, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Clock, Flame, Heart } from 'lucide-react-native';

const { width } = Dimensions.get('window');

export default function ActivityScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <Text style={styles.title}>Activity</Text>
        
        <View style={styles.summaryContainer}>
          <View style={styles.summaryCard}>
            <Clock size={24} color="#007AFF" />
            <Text style={styles.summaryValue}>45 min</Text>
            <Text style={styles.summaryLabel}>Active Time</Text>
          </View>
          <View style={styles.summaryCard}>
            <Flame size={24} color="#FF3B30" />
            <Text style={styles.summaryValue}>324</Text>
            <Text style={styles.summaryLabel}>Calories</Text>
          </View>
          <View style={styles.summaryCard}>
            <Heart size={24} color="#FF2D55" />
            <Text style={styles.summaryValue}>72</Text>
            <Text style={styles.summaryLabel}>Avg BPM</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Today's Activities</Text>
        
        <View style={styles.activityList}>
          <View style={styles.activityItem}>
            <View style={styles.activityIcon}>
              <Clock size={20} color="#007AFF" />
            </View>
            <View style={styles.activityInfo}>
              <Text style={styles.activityTitle}>Morning Walk</Text>
              <Text style={styles.activityDetails}>30 mins • 2.5 km • 156 cal</Text>
            </View>
            <Text style={styles.activityTime}>8:00 AM</Text>
          </View>

          <View style={styles.activityItem}>
            <View style={[styles.activityIcon, { backgroundColor: '#FFE5E5' }]}>
              <Heart size={20} color="#FF2D55" />
            </View>
            <View style={styles.activityInfo}>
              <Text style={styles.activityTitle}>Yoga Session</Text>
              <Text style={styles.activityDetails}>45 mins • 168 cal</Text>
            </View>
            <Text style={styles.activityTime}>10:30 AM</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Weekly Progress</Text>
        <View style={styles.progressCard}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: width * 0.6 }]} />
          </View>
          <Text style={styles.progressText}>4 of 7 days completed</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 32,
    color: '#000',
    marginBottom: 24,
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 32,
  },
  summaryCard: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginHorizontal: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  summaryValue: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 20,
    color: '#000',
    marginTop: 8,
  },
  summaryLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  sectionTitle: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 20,
    color: '#000',
    marginBottom: 16,
  },
  activityList: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f1f1',
  },
  activityIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E3F2FF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  activityInfo: {
    flex: 1,
    marginLeft: 12,
  },
  activityTitle: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 16,
    color: '#000',
  },
  activityDetails: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  activityTime: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
  },
  progressCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#F1F1F1',
    borderRadius: 4,
    marginBottom: 12,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#007AFF',
    borderRadius: 4,
  },
  progressText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
});