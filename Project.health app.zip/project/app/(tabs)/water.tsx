import { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plus, Minus, Bell, Trophy } from 'lucide-react-native';

export default function WaterScreen() {
  const [waterIntake, setWaterIntake] = useState(1200); // in ml
  const dailyGoal = 2500; // in ml
  const percentage = Math.min((waterIntake / dailyGoal) * 100, 100);

  const addWater = (amount: number) => {
    setWaterIntake(prev => Math.min(prev + amount, dailyGoal));
  };

  const removeWater = (amount: number) => {
    setWaterIntake(prev => Math.max(prev - amount, 0));
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <Text style={styles.title}>Water Intake</Text>

        <View style={styles.progressContainer}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=800' }}
            style={styles.backgroundImage}
          />
          <View style={styles.progressOverlay}>
            <Text style={styles.progressText}>{Math.round(percentage)}%</Text>
            <Text style={styles.progressSubtext}>{waterIntake}ml / {dailyGoal}ml</Text>
          </View>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${percentage}%` }]} />
          </View>
        </View>

        <View style={styles.quickActions}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => addWater(250)}
          >
            <View style={styles.actionIcon}>
              <Plus size={24} color="#007AFF" />
            </View>
            <Text style={styles.actionText}>Add Glass</Text>
            <Text style={styles.actionSubtext}>250ml</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => addWater(500)}
          >
            <View style={styles.actionIcon}>
              <Plus size={24} color="#007AFF" />
            </View>
            <Text style={styles.actionText}>Add Bottle</Text>
            <Text style={styles.actionSubtext}>500ml</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => removeWater(250)}
          >
            <View style={[styles.actionIcon, { backgroundColor: '#FFE5E5' }]}>
              <Minus size={24} color="#FF3B30" />
            </View>
            <Text style={styles.actionText}>Remove</Text>
            <Text style={styles.actionSubtext}>250ml</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.sectionTitle}>Today's Schedule</Text>
        <View style={styles.scheduleCard}>
          {[9, 11, 13, 15, 17, 19].map((hour, index) => (
            <View key={hour} style={styles.scheduleItem}>
              <View style={[styles.scheduleIcon, { backgroundColor: hour <= new Date().getHours() ? '#E3F2FF' : '#F8F9FA' }]}>
                <Bell size={20} color={hour <= new Date().getHours() ? '#007AFF' : '#8E8E93'} />
              </View>
              <View style={styles.scheduleInfo}>
                <Text style={styles.scheduleTime}>{hour}:00</Text>
                <Text style={styles.scheduleText}>Drink 250ml of water</Text>
              </View>
              {hour <= new Date().getHours() && (
                <View style={styles.scheduleComplete}>
                  <Trophy size={16} color="#34C759" />
                </View>
              )}
            </View>
          ))}
        </View>

        <Text style={styles.sectionTitle}>Benefits</Text>
        <View style={styles.benefitsCard}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1616118132534-381148898bb4?w=800' }}
            style={styles.benefitImage}
          />
          <View style={styles.benefitContent}>
            <Text style={styles.benefitTitle}>Stay Hydrated, Stay Healthy</Text>
            <Text style={styles.benefitText}>
              Drinking enough water helps maintain body temperature, remove waste, and lubricate joints. It can also help improve sleep quality, cognition, and mood.
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 32,
    color: '#000',
    marginBottom: 24,
  },
  progressContainer: {
    height: 240,
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  backgroundImage: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    opacity: 0.1,
  },
  progressOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 48,
    color: '#007AFF',
  },
  progressSubtext: {
    fontFamily: 'Inter_400Regular',
    fontSize: 16,
    color: '#666',
    marginTop: 8,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#F1F1F1',
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 4,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#007AFF',
    borderRadius: 4,
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginHorizontal: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#E3F2FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  actionText: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 14,
    color: '#000',
  },
  actionSubtext: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  sectionTitle: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 20,
    color: '#000',
    marginBottom: 16,
  },
  scheduleCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  scheduleItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F1F1',
  },
  scheduleIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  scheduleInfo: {
    flex: 1,
  },
  scheduleTime: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: '#000',
  },
  scheduleText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  scheduleComplete: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#E8FAE9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  benefitsCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  benefitImage: {
    width: '100%',
    height: 160,
  },
  benefitContent: {
    padding: 16,
  },
  benefitTitle: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 18,
    color: '#000',
    marginBottom: 8,
  },
  benefitText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
});