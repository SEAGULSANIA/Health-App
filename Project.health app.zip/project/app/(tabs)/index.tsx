import { View, Text, ScrollView, StyleSheet, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.greeting}>Good morning,</Text>
          <Text style={styles.name}>Sarah</Text>
        </View>

        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>7,234</Text>
            <Text style={styles.statLabel}>Steps Today</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>1,634</Text>
            <Text style={styles.statLabel}>Calories</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Today's Workout</Text>
        <View style={styles.workoutCard}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800' }}
            style={styles.workoutImage}
          />
          <View style={styles.workoutInfo}>
            <Text style={styles.workoutTitle}>Morning Yoga</Text>
            <Text style={styles.workoutDuration}>30 mins • Beginner</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Wellness Tips</Text>
        <View style={styles.tipCard}>
          <Text style={styles.tipTitle}>Stay Hydrated</Text>
          <Text style={styles.tipText}>
            Remember to drink at least 8 glasses of water today to maintain optimal health and energy levels.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  header: {
    marginBottom: 24,
  },
  greeting: {
    fontFamily: 'Inter_400Regular',
    fontSize: 16,
    color: '#666',
  },
  name: {
    fontFamily: 'Inter_700Bold',
    fontSize: 24,
    color: '#000',
    marginTop: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  statValue: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 24,
    color: '#007AFF',
    marginBottom: 4,
  },
  statLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
  },
  sectionTitle: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 20,
    color: '#000',
    marginBottom: 16,
  },
  workoutCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  workoutImage: {
    width: '100%',
    height: 160,
  },
  workoutInfo: {
    padding: 16,
  },
  workoutTitle: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 18,
    color: '#000',
    marginBottom: 4,
  },
  workoutDuration: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
  },
  tipCard: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  tipTitle: {
    fontFamily: 'PlusJakartaSans_500Medium',
    fontSize: 16,
    color: '#000',
    marginBottom: 8,
  },
  tipText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
});