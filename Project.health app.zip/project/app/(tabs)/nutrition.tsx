import { View, Text, ScrollView, StyleSheet, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function NutritionScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <Text style={styles.title}>Nutrition</Text>

        <View style={styles.calorieCard}>
          <Text style={styles.calorieTitle}>Daily Calories</Text>
          <View style={styles.calorieStats}>
            <Text style={styles.calorieValue}>1,634</Text>
            <Text style={styles.calorieGoal}>/ 2,000 kcal</Text>
          </View>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '75%' }]} />
          </View>
        </View>

        <Text style={styles.sectionTitle}>Today's Meals</Text>
        
        <View style={styles.mealCard}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1494597564530-871f2b93ac55?w=800' }}
            style={styles.mealImage}
          />
          <View style={styles.mealInfo}>
            <View>
              <Text style={styles.mealTime}>Breakfast</Text>
              <Text style={styles.mealName}>Oatmeal with Berries</Text>
            </View>
            <Text style={styles.mealCalories}>320 kcal</Text>
          </View>
        </View>

        <View style={styles.mealCard}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800' }}
            style={styles.mealImage}
          />
          <View style={styles.mealInfo}>
            <View>
              <Text style={styles.mealTime}>Lunch</Text>
              <Text style={styles.mealName}>Quinoa Salad Bowl</Text>
            </View>
            <Text style={styles.mealCalories}>450 kcal</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Nutrition Breakdown</Text>
        <View style={styles.nutritionCard}>
          <View style={styles.nutrientItem}>
            <Text style={styles.nutrientLabel}>Protein</Text>
            <Text style={styles.nutrientValue}>65g</Text>
            <View style={styles.nutrientBar}>
              <View style={[styles.nutrientFill, { width: '80%', backgroundColor: '#007AFF' }]} />
            </View>
          </View>
          
          <View style={styles.nutrientItem}>
            <Text style={styles.nutrientLabel}>Carbs</Text>
            <Text style={styles.nutrientValue}>180g</Text>
            <View style={styles.nutrientBar}>
              <View style={[styles.nutrientFill, { width: '60%', backgroundColor: '#FF9500' }]} />
            </View>
          </View>
          
          <View style={styles.nutrientItem}>
            <Text style={styles.nutrientLabel}>Fat</Text>
            <Text style={styles.nutrientValue}>45g</Text>
            <View style={styles.nutrientBar}>
              <View style={[styles.nutrientFill, { width: '40%', backgroundColor: '#FF3B30' }]} />
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 32,
    color: '#000',
    marginBottom: 24,
  },
  calorieCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  calorieTitle: {
    fontFamily: 'PlusJakartaSans_500Medium',
    fontSize: 16,
    color: '#666',
  },
  calorieStats: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginTop: 8,
  },
  calorieValue: {
    fontFamily: 'Inter_700Bold',
    fontSize: 32,
    color: '#000',
  },
  calorieGoal: {
    fontFamily: 'Inter_400Regular',
    fontSize: 16,
    color: '#666',
    marginLeft: 4,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#F1F1F1',
    borderRadius: 4,
    marginTop: 16,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#007AFF',
    borderRadius: 4,
  },
  sectionTitle: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 20,
    color: '#000',
    marginBottom: 16,
  },
  mealCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  mealImage: {
    width: '100%',
    height: 160,
  },
  mealInfo: {
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  mealTime: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
  },
  mealName: {
    fontFamily: 'PlusJakartaSans_600SemiBold',
    fontSize: 16,
    color: '#000',
    marginTop: 4,
  },
  mealCalories: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: '#007AFF',
  },
  nutritionCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  nutrientItem: {
    marginBottom: 16,
  },
  nutrientLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  nutrientValue: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: '#000',
    marginBottom: 8,
  },
  nutrientBar: {
    height: 8,
    backgroundColor: '#F1F1F1',
    borderRadius: 4,
  },
  nutrientFill: {
    height: '100%',
    borderRadius: 4,
  },
});