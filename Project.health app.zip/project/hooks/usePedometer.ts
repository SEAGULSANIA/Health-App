import { useState, useEffect } from 'react';
import { Platform } from 'react-native';

interface StepCount {
  steps: number;
  error: string | null;
}

export function usePedometer(): StepCount {
  const [stepCount, setStepCount] = useState<StepCount>({ steps: 0, error: null });

  useEffect(() => {
    if (Platform.OS === 'web') {
      // Check if the Web Pedometer API is available
      if ('Pedometer' in window) {
        let pedometer: any;
        
        const startPedometer = async () => {
          try {
            // Request permission and start counting steps
            const permission = await (navigator as any).permissions.query({ name: 'activity-recognition' });
            
            if (permission.state === 'granted') {
              pedometer = new (window as any).Pedometer();
              pedometer.addEventListener('reading', (event: any) => {
                setStepCount({ steps: event.steps, error: null });
              });
              await pedometer.start();
            } else {
              setStepCount(prev => ({ ...prev, error: 'Permission denied' }));
            }
          } catch (error) {
            setStepCount(prev => ({ ...prev, error: 'Pedometer not available' }));
            // Simulate step counting for demo purposes
            simulateSteps();
          }
        };

        startPedometer();

        return () => {
          if (pedometer) {
            pedometer.stop();
          }
        };
      } else {
        // Fallback: Simulate step counting
        simulateSteps();
      }
    }
  }, []);

  // Simulate step counting for demo or when sensors are not available
  const simulateSteps = () => {
    const interval = setInterval(() => {
      setStepCount(prev => ({
        ...prev,
        steps: prev.steps + Math.floor(Math.random() * 3),
      }));
    }, 2000);

    return () => clearInterval(interval);
  };

  return stepCount;
}